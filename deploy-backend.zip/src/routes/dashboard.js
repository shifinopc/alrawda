﻿const express = require('express');
const { query } = require('../db');
const { requirePermission } = require('../permissions');

const router = express.Router();

// notification counts the header bell needs — cheap, and available to ANY authenticated
// user (it isn't dashboard data), so it works even for users without Dashboard access.
const SQL_UNBOOKED = `SELECT COUNT(*) AS c FROM UmrahReciept r
   WHERE r.is_deleted = 0 AND (r.ReceiptApproved IS NULL OR TRIM(r.ReceiptApproved) = '')
     AND NOT EXISTS (
       SELECT 1 FROM receipt_request_dtl d
       JOIN receipt_request rr ON rr.id = d.request_id
       WHERE d.receipt_code = r.RecieptCode AND rr.status = 'Pending' AND d.status = 'Pending')`;
const SQL_TO_APPROVE = `SELECT COUNT(*) AS c FROM UmrahInvoice
   WHERE is_deleted = 0 AND TRIM(IFNULL(ApprovalStatus,'Pending')) = 'Pending' AND TRIM(IFNULL(CancelYesNo,'N')) <> 'Y'`;

// GET /api/dashboard/counts — bell badges only (no Dashboard permission required)
router.get('/counts', async (_req, res) => {
  const [[unbooked], [toApprove]] = await Promise.all([query(SQL_UNBOOKED), query(SQL_TO_APPROVE)]);
  res.json({ unbookedReceipts: unbooked.c, invoicesToApprove: toApprove.c });
});

// Pending (unsettled) invoices, oldest first, filtered by how many days old the invoice is.
/* ---- instalments due (EMI plans) ----
 * Which instalments are still owed, and when. A row's paid share is the plan's
 * allocation (oldest first) landing on it, so this matches what the plan modal
 * and the printed schedule show, without storing anything twice.
 * Plans that no longer add up are left out and counted separately — chasing a
 * figure we know is wrong would be worse than saying nothing. */
const INSTALMENT_SQL = `
  WITH rows_ AS (
    SELECT d.invoice_code, d.seq, d.due_date, d.amount,
           SUM(d.amount) OVER (PARTITION BY d.invoice_code ORDER BY d.seq
                               ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cum,
           GREATEST(0, IFNULL(r.received,0) - p.opening_paid) AS allocated,
           (i.NetAmount - IFNULL(r.received,0)) + GREATEST(0, IFNULL(r.received,0) - p.opening_paid)
             <> p.planned_amount AS is_stale,
           i.InvoiceNo, i.InvoiceDate, i.created_at AS CreatedAt, i.CustomerName, i.Mobile1
    FROM payment_plan_dtl d
    JOIN payment_plan p   ON p.invoice_code = d.invoice_code AND p.status = 'Active'
    JOIN UmrahInvoice i   ON i.InvoiceCode = d.invoice_code
                         AND i.is_deleted = 0 AND TRIM(IFNULL(i.CancelYesNo,'N')) <> 'Y'
    LEFT JOIN (SELECT InvoiceCode, SUM(RecievedAmount) received FROM UmrahReciept
               WHERE is_deleted = 0 GROUP BY InvoiceCode) r ON r.InvoiceCode = d.invoice_code
  )
  SELECT invoice_code AS InvoiceCode, InvoiceNo, InvoiceDate, CreatedAt, CustomerName, Mobile1,
         seq, due_date AS dueDate, amount,
         amount - LEAST(amount, GREATEST(0, allocated - (cum - amount))) AS outstanding,
         DATEDIFF(CURDATE(), due_date) AS daysLate, is_stale
  FROM rows_
  WHERE is_stale = 0 AND amount - LEAST(amount, GREATEST(0, allocated - (cum - amount))) > 0`;

const SCOPES = {
  overdue: 'due_date < CURDATE()',
  // inclusive of the last day: an instalment due exactly 30 days out is still
  // "in the next 30 days", and silently dropping it would under-report collections
  week: 'due_date >= CURDATE() AND due_date <= CURDATE() + INTERVAL 7 DAY',
  month: 'due_date >= CURDATE() AND due_date <= CURDATE() + INTERVAL 30 DAY',
};

// GET /api/dashboard/instalments?scope=overdue|week|month&page=1&pageSize=6
router.get('/instalments', requirePermission('Dashboard', 'View'), async (req, res) => {
  const scope = SCOPES[req.query.scope] ? req.query.scope : 'overdue';
  const page = Math.max(1, Number(req.query.page) || 1);
  const pageSize = Math.min(50, Math.max(1, Number(req.query.pageSize) || 6));

  const rows = await query(
    `SELECT * FROM (${INSTALMENT_SQL}) t WHERE ${SCOPES[scope].replace(/due_date/g, 't.dueDate')}
     ORDER BY t.dueDate ASC, t.InvoiceNo ASC LIMIT ? OFFSET ?`,
    [pageSize, (page - 1) * pageSize]
  );
  // headline numbers for all three ranges, so the chips can carry their own totals
  const [tot] = await query(
    `SELECT
       SUM(${SCOPES.overdue.replace(/due_date/g, 't.dueDate')}) AS overdueCount,
       SUM(CASE WHEN ${SCOPES.overdue.replace(/due_date/g, 't.dueDate')} THEN t.outstanding ELSE 0 END) AS overdueAmount,
       SUM(${SCOPES.week.replace(/due_date/g, 't.dueDate')}) AS weekCount,
       SUM(CASE WHEN ${SCOPES.week.replace(/due_date/g, 't.dueDate')} THEN t.outstanding ELSE 0 END) AS weekAmount,
       SUM(${SCOPES.month.replace(/due_date/g, 't.dueDate')}) AS monthCount,
       SUM(CASE WHEN ${SCOPES.month.replace(/due_date/g, 't.dueDate')} THEN t.outstanding ELSE 0 END) AS monthAmount
     FROM (${INSTALMENT_SQL}) t`);
  const [stale] = await query(
    `SELECT COUNT(*) AS n FROM payment_plan p
     JOIN UmrahInvoice i ON i.InvoiceCode = p.invoice_code AND i.is_deleted = 0
     LEFT JOIN (SELECT InvoiceCode, SUM(RecievedAmount) received FROM UmrahReciept
                WHERE is_deleted = 0 GROUP BY InvoiceCode) r ON r.InvoiceCode = p.invoice_code
     WHERE p.status = 'Active'
       AND (i.NetAmount - IFNULL(r.received,0)) + GREATEST(0, IFNULL(r.received,0) - p.opening_paid)
           <> p.planned_amount`);
  const totals = {
    overdue: { count: Number(tot?.overdueCount || 0), amount: Number(tot?.overdueAmount || 0) },
    week: { count: Number(tot?.weekCount || 0), amount: Number(tot?.weekAmount || 0) },
    month: { count: Number(tot?.monthCount || 0), amount: Number(tot?.monthAmount || 0) },
  };
  res.json({ rows, scope, page, pageSize, total: totals[scope].count, totals, staleCount: Number(stale?.n || 0) });
});

// GET /api/dashboard/pending-invoices?minAge=30&maxAge=&page=1&pageSize=8
router.get('/pending-invoices', requirePermission('Dashboard', 'View'), async (req, res) => {
  const minAge = Math.max(0, Number(req.query.minAge) || 0);
  const maxAge = req.query.maxAge === '' || req.query.maxAge == null ? null : Number(req.query.maxAge);
  const page = Math.max(1, Number(req.query.page) || 1);
  const pageSize = Math.min(50, Math.max(1, Number(req.query.pageSize) || 8));

  const where = [
    'i.is_deleted = 0',
    `TRIM(IFNULL(i.CancelYesNo,'N')) <> 'Y'`,
    '(i.NetAmount - IFNULL(r.received,0)) > 0',
    'DATEDIFF(CURDATE(), DATE(i.InvoiceDate)) >= ?',
  ];
  const params = [minAge];
  if (Number.isFinite(maxAge)) { where.push('DATEDIFF(CURDATE(), DATE(i.InvoiceDate)) <= ?'); params.push(maxAge); }
  const whereSql = where.join(' AND ');
  const joinSql = `FROM UmrahInvoice i
     LEFT JOIN (SELECT InvoiceCode, SUM(RecievedAmount) received FROM UmrahReciept WHERE is_deleted=0 GROUP BY InvoiceCode) r
       ON r.InvoiceCode = i.InvoiceCode
     WHERE ${whereSql}`;

  const rows = await query(
    `SELECT i.InvoiceCode, i.InvoiceNo, i.InvoiceDate, i.created_at AS CreatedAt, i.CustomerName, i.Mobile1,
            i.NetAmount AS InvoiceAmount, IFNULL(r.received,0) AS ReceivedAmount,
            (i.NetAmount - IFNULL(r.received,0)) AS Balance,
            DATEDIFF(CURDATE(), DATE(i.InvoiceDate)) AS AgeDays
     ${joinSql}
     ORDER BY AgeDays DESC, i.InvoiceNo DESC
     LIMIT ? OFFSET ?`,
    [...params, pageSize, (page - 1) * pageSize]
  );
  const [summary] = await query(
    `SELECT COUNT(*) AS total, IFNULL(SUM(i.NetAmount - IFNULL(r.received,0)),0) AS balance ${joinSql}`,
    params
  );
  res.json({
    rows, page, pageSize,
    total: Number(summary.total),
    balance: Number(summary.balance),
  });
});

// GET /api/dashboard?from=YYYY-MM-DD&to=YYYY-MM-DD  (full dashboard — needs Dashboard → View)
router.get('/', requirePermission('Dashboard', 'View'), async (req, res) => {
  const to = req.query.to || new Date().toLocaleDateString('en-CA');
  const from = req.query.from || new Date(Date.now() - 29 * 86400000).toLocaleDateString('en-CA');

  const [collection] = await query(
    `SELECT IFNULL(SUM(RecievedAmount),0) AS total FROM UmrahReciept WHERE is_deleted=0 AND DATE(RecieptDate) BETWEEN ? AND ?`,
    [from, to]
  );
  const [pending] = await query(
    `SELECT IFNULL(SUM(i.NetAmount - IFNULL(r.received,0)),0) AS total
     FROM UmrahInvoice i
     LEFT JOIN (SELECT InvoiceCode, SUM(RecievedAmount) received FROM UmrahReciept WHERE is_deleted=0 GROUP BY InvoiceCode) r
       ON r.InvoiceCode = i.InvoiceCode
     WHERE i.is_deleted = 0 AND TRIM(IFNULL(i.CancelYesNo,'N')) <> 'Y' AND (i.NetAmount - IFNULL(r.received,0)) > 0`
  );
  const [unbooked] = await query(SQL_UNBOOKED);
  const [toApprove] = await query(SQL_TO_APPROVE);

  const trend = await query(
    `SELECT DATE_FORMAT(RecieptDate, '%Y-%m-%d') AS d, SUM(RecievedAmount) AS amount
     FROM UmrahReciept WHERE is_deleted=0 AND DATE(RecieptDate) BETWEEN ? AND ?
     GROUP BY DATE_FORMAT(RecieptDate, '%Y-%m-%d') ORDER BY d`,
    [from, to]
  );

  const byPackage = await query(
    `SELECT IFNULL(p.PackageName,'Other') AS name, SUM(r.RecievedAmount) AS amount
     FROM UmrahReciept r
     JOIN UmrahInvoice i ON i.InvoiceCode = r.InvoiceCode
     LEFT JOIN UmrahPackage p ON p.PackageCode = i.PackageCode
     WHERE r.is_deleted = 0 AND DATE(r.RecieptDate) BETWEEN ? AND ?
     GROUP BY IFNULL(p.PackageName,'Other') ORDER BY amount DESC LIMIT 5`,
    [from, to]
  );

  const incomeExpense = await query(
    `SELECT m, SUM(income) AS income, SUM(expense) AS expense FROM (
       SELECT DATE_FORMAT(RecieptDate,'%Y-%m') AS m, RecievedAmount AS income, 0 AS expense
       FROM UmrahReciept WHERE is_deleted=0 AND RecieptDate >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
       UNION ALL
       SELECT DATE_FORMAT(PaymentDate,'%Y-%m'), 0, PaymentAmount
       FROM UmrahPayment WHERE is_deleted=0 AND PaymentDate >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
     ) x GROUP BY m ORDER BY m`
  );

  const departures = await query(
    `SELECT DATE_FORMAT(DepartureDate, '%Y-%m-%d') AS d, SUM(IFNULL(PassengerCount,0)) AS pax
     FROM UmrahInvoice
     WHERE is_deleted = 0 AND DepartureDate >= CURDATE() AND TRIM(IFNULL(CancelYesNo,'N')) <> 'Y'
     GROUP BY DATE_FORMAT(DepartureDate, '%Y-%m-%d') ORDER BY d LIMIT 8`
  );

  const recentInvoices = await query(
    `SELECT i.InvoiceCode, i.InvoiceNo, i.InvoiceDate, i.CustomerName, i.NetAmount,
            IFNULL(r.received,0) AS received,
            CASE WHEN TRIM(IFNULL(i.CancelYesNo,'N'))='Y' THEN 'Cancelled'
                 WHEN i.NetAmount - IFNULL(r.received,0) <= 0 THEN 'Paid'
                 WHEN IFNULL(r.received,0) > 0 THEN 'Partially Paid'
                 ELSE 'Not Paid' END AS status
     FROM UmrahInvoice i
     LEFT JOIN (SELECT InvoiceCode, SUM(RecievedAmount) received FROM UmrahReciept WHERE is_deleted=0 GROUP BY InvoiceCode) r
       ON r.InvoiceCode = i.InvoiceCode
     WHERE i.is_deleted = 0
     ORDER BY i.InvoiceCode DESC LIMIT 6`
  );

  const recentReceipts = await query(
    `SELECT r.RecieptCode, r.RecieptNo, r.RecieptDate, r.RecievedAmount, i.CustomerName
     FROM UmrahReciept r LEFT JOIN UmrahInvoice i ON i.InvoiceCode = r.InvoiceCode
     WHERE r.is_deleted = 0
     ORDER BY r.RecieptCode DESC LIMIT 6`
  );

  res.json({
    kpis: {
      totalCollection: Number(collection.total),
      pendingBalance: Number(pending.total),
      unbookedReceipts: unbooked.c,
      invoicesToApprove: toApprove.c,
    },
    trend, byPackage, incomeExpense, departures, recentInvoices, recentReceipts,
    period: { from, to },
  });
});

module.exports = router;
